package com.samsung.bookm.Interface;

public interface ITransferData {
    public void delete(int position);
}
